from pymongo import MongoClient
from bson.objectid import ObjectId

class CRUD(object):

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30209
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (username,password,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        print("Successfully loaded database")

# Create
    def create(self, data):
        try:
            if data is None or data == {}:
                raise Exception("Nothing to search, because the target parameter is empty")
                return false
            else:
                doc = self.collection.find_one(data)
                if doc is None:
                    self.collection.insert_one(data)
                    print("Successfully added data")
                    return true
                else:
                    print("Data already exists")
                    return false
        except Exception as e:
            print("An exception occurred: ", e)

# Read
    def read(self, data):
        try:
            if data is None or data == {}:
                raise Exception("Nothing to search, because the target parameter is empty")
                return false
            else:
                doc = self.collection.find_one(data)
                if doc is None:
                    print("Could not find data")
                    return false
                else:
                    docs = self.collection.find_one(data)
                    for item in docs:
                        print(item)
                    return docs
        except Exception as e:
            print("An exception occurred: ", e)
  
#Read All
    def readAll(self, data):
        # try/except block for testing in the unit tests
        try:
            if data is not None:
                read_result = list(self.database.animals.find(data, {"_id":False}))
                
                return read_result
            else:
                raise Exception("Nothing to search")
                return False
        except Exception as e:
            print("An exception occurred: ", e)




    
#Update
    def update(self, data, new):
        try:
            if data is None or data == {}:
                print("Data not found, data is empty")
                return false
            else:
                doc = self.collection.find_one(data)
                if doc is None:
                    print("Data not found")
                    return false
                else:
                    self.collection.update_one(data, {"$set": new})
                    print("Successfully update data")
                    return 1
        except Exception as e:
            print("An exception occurred: ", e)
               
#Delete
    def delete(self, data):
        try:
            if data is None or data == {}:
                print("Data is empty")
                return false
            else:
                doc = self.collection.find_one(data)
                if doc is None:
                    print("Data not found")
                    return false
                else:
                    self.collection.delete_one(data)
                    print("Data successfully deleted")
                    return 1
        except Exception as e:
            print("An exception occurred: ", e)
